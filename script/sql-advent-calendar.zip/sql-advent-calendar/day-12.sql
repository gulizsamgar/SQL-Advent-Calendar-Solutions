-- SQL Advent Calendar - Day 12
-- Title: North Pole Network Most Active Users
-- Difficulty: hard
--
-- Question:
-- The North Pole Network wants to see who's the most active in the holiday chat each day. Write a query to count how many messages each user sent, then find the most active user(s) each day. If multiple users tie for first place, return all of them.
--
-- The North Pole Network wants to see who's the most active in the holiday chat each day. Write a query to count how many messages each user sent, then find the most active user(s) each day. If multiple users tie for first place, return all of them.
--

-- Table Schema:
-- Table: npn_users
--   user_id: INT
--   user_name: VARCHAR
--
-- Table: npn_messages
--   message_id: INT
--   sender_id: INT
--   sent_at: TIMESTAMP
--

-- My Solution:

WITH daily_counts AS (
    SELECT 
        DATE(m.sent_at) AS message_date,
        u.user_id,
        u.user_name,
        COUNT(m.sender_id) AS message_count
    FROM npn_messages m
    JOIN npn_users u ON u.user_id = m.sender_id
    GROUP BY DATE(m.sent_at), u.user_id
),
daily_max AS(
  SELECT 
  message_date,
  MAX(message_count) AS max_count
  FROM daily_counts
  GROUP BY message_date
)
SELECT
d.message_date,
d.user_id,
d.user_name,
m.max_count
FROM daily_counts d
JOIN daily_max m 
  ON d.message_date = m.message_date
  AND d.message_count = m.max_count
ORDER BY d.message_date;
